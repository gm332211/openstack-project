#-*- coding: utf-8 -*-
import threading
import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from views.thread_schedule import Producer_Create,Producer_Delete,Threading_Create,Threading_delete
p1 = threading.Thread(target=Producer_Create)
c1 = threading.Thread(target=Threading_Create,kwargs={'count':5})
p2 = threading.Thread(target=Producer_Delete)
c2 = threading.Thread(target=Threading_delete,kwargs={'count':5})
print('running.....')
p1.start()
p2.start()
c1.start()
c2.start()