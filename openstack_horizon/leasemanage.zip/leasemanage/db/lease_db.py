#-*- coding: utf-8 -*-
from sqlalchemy import Column,String,DateTime,Integer,create_engine
from sqlalchemy.ext.declarative import declarative_base
Base=declarative_base()
class Appointment(Base):
    __tablename__='appointment'
    id=Column(Integer,primary_key=True)
    instance_name=Column(String(64))
    image_id=Column(String(64))
    flavor_id=Column(String(64))
    network_id=Column(String(64))
    start_time=Column(DateTime)
    stop_time=Column(DateTime)
    def __str__(self):
        return self.instance_name
class InstanceProblem(Base):
    __tablename__='instance_problem'
    id=Column(Integer,primary_key=True)
    instance_name=Column(String(64))
    image_id=Column(String(64))
    flavor_id=Column(String(64))
    network_id=Column(String(64))
    start_time=Column(DateTime)
    stop_time=Column(DateTime)
    status=Column(String(64))
    message=Column(String(128))
    def __str__(self):
        return '%s:%s'%(self.status,self.instance_name)
class InstanceSuccess(Base):
    __tablename__ = 'instance_success'
    id = Column(Integer, primary_key=True)
    instance_id = Column(String(64))
    start_time = Column(DateTime)
    stop_time=Column(DateTime)
    def __str__(self):
        return '%s'%(self.instance_id)
engine=create_engine('mysql+pymysql://root:password@172.24.2.10:3306/timemanage',encoding='utf-8')
Base.metadata.create_all(engine)

