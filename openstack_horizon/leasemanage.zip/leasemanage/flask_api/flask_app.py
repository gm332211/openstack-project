#-*- coding: utf-8 -*-
from flask import Flask
from flask import request
from flask import jsonify
import datetime
import os,sys
import json
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from views import db_views
from views.openstack_views import openstack
op=openstack(ip='172.24.2.10',username='admin',password='password',project='demo')
app=Flask(__name__)
@app.route('/')
def index():
    return 'welcome to index'
@app.route('/lease/servers',methods=['POST'])
def create_server_manage():
    data=request.json
    print(type(data))
    instance_name = data.get('instance_name',None)
    image_id = data.get('image_id',None)
    flavor_id = data.get('flavor_id',None)
    network_id = data.get('network_id',None)
    start_time = data.get('start_time',None)
    stop_time = data.get('stop_time',None)
    print(instance_name,image_id,flavor_id,network_id,start_time,stop_time)
    if instance_name and image_id and flavor_id and network_id and start_time and stop_time:
        startTime = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
        stopTime = datetime.datetime.strptime(stop_time, '%Y-%m-%d %H:%M:%S')
        print(startTime,stopTime)
        db_views.create_app_db(instance_name=instance_name, image_id=image_id, flavor_id=flavor_id, network_id=network_id,
                      start_time=startTime, stop_time=stopTime)
        print(1)
        return 'ok'

    else:
        print(2)
        return 'error'
@app.route('/lease/servers',methods=['GET'])
def list_server_manage():
    data_dic={}
    db_objs=db_views.find_all_app_db()
    if db_objs:
        for db_obj in db_objs:
            data_dic[db_obj.id]={
                'uuid':str(db_obj.id),
                'instance_name':db_obj.instance_name,
                'image_id':db_obj.image_id,
                'flavor_id':db_obj.flavor_id,
                'network_id':db_obj.network_id,
                'start_time':db_obj.start_time.strftime("%Y-%m-%d %H:%S:%M"),
                'stop_time':db_obj.stop_time.strftime("%Y-%m-%d %H:%S:%M"),
            }
    return jsonify(data_dic)
@app.route('/lease/servers/<id>',methods=['DELETE'])
def delete_server_manage(id):
    db_obj=db_views.find_app_db(id)
    if db_obj:
        db_views.delete_db(db_obj)
        return jsonify({'info':'204'})
    else:
        return jsonify({'error':'404'})
@app.route('/lease/servers/<id>',methods=['PUT'])
def update_server_manage(id):
    pass
@app.route('/lease/instances',methods=['GET'])
def list_instance():
    db_objs=db_views.find_all_instance_db()
    data_dic={}
    if db_objs:
        for db_obj in db_objs:
            data_dic[db_obj.id]={
                'uuid':db_obj.id,
                'instance_id': db_obj.instance_id,
                'start_time': db_obj.start_time.strftime("%Y-%m-%d %H:%S:%M"),
                'stop_time': db_obj.stop_time.strftime("%Y-%m-%d %H:%S:%M"),
            }
    return jsonify(data_dic)
@app.route('/lease/instances/<id>',methods=['DELETE'])
def delete_instance(id):
    db_obj=db_views.find_instance_db(id)
    if db_obj:
        db_views.delete_db(db_obj)
        return jsonify({'info':'204'})
    else:
        return jsonify({'error':'404'})
@app.route('/lease/instances/<id>',methods=['GET'])
def get_instance(id):
    db_obj = db_views.find_instance_db(id)
    db_dict={}
    if db_obj:
        db_dict={
            'id':db_obj.id,
            'instance_id': db_obj.instance_id,
            'start_time': db_obj.stop_time.strftime("%Y-%m-%d %H:%S:%M"),
            'stop_time': db_obj.stop_time.strftime("%Y-%m-%d %H:%S:%M"),
        }
    return jsonify(db_dict)
@app.route('/lease/failures',methods=['GET'])
def list_failure():
    db_dict={}
    db_objs=db_views.find_all_failure_db()
    if db_objs:
        for db_obj in db_objs:
            db_dict[db_obj.id]={
                'uuid':str(db_obj.id),
                'instance_name':db_obj.instance_name,
                'image_id':db_obj.image_id,
                'flavor_id':db_obj.flavor_id,
                'network_id':db_obj.network_id,
                'start_time':db_obj.start_time.strftime("%Y-%m-%d %H:%S:%M"),
                'stop_time':db_obj.stop_time.strftime("%Y-%m-%d %H:%S:%M"),
                'status':db_obj.status,
                'message': db_obj.message,
            }
    return jsonify(db_dict)
@app.route('/lease/failures/<id>',methods=['DELETE'])
def delete_failure(id):
    db_obj=db_views.find_failure_db(id)
    if db_obj:
        db_views.delete_db(db_obj)
        return jsonify({'info':'204'})
    else:
        return jsonify({'error':'404'})
@app.route('/lease/failures/<id>',methods=['PUT'])
def reset_failure(id):
    db_obj=db_views.find_failure_db(id)
    if db_obj:
        db_views.create_app_db(
            instance_name=db_obj.instance_name,
            image_id=db_obj.image_id,
            flavor_id=db_obj.flavor_id,
            network_id=db_obj.network_id,
            start_time=db_obj.start_time,
            stop_time=db_obj.stop_time,
        )
        db_views.delete_db(db_obj)
        return jsonify({'info':'204'})
    else:
        return jsonify({'error':'404'})
app.run('0.0.0.0',port=8567,debug=True,threaded=True)