#-*- coding: utf-8 -*-
from keystoneauth1 import loading
from keystoneauth1 import session
from keystoneclient.v3 import client
from novaclient import client
loader=loading.get_plugin_loader('password')
auth=loader.load_from_options(
    auth_url='http://172.24.2.10/identity/v3',
    username='admin',
    password='password',
    project_name='demo',
    user_domain_id='default',
    project_domain_id='default'
)
sess = session.Session(auth=auth,verify='/path/to/ca.cert')

# nova = client.Client('2.1', session=sess)
nova_test=client.Client('2.1',session=sess)
a=nova_test.servers.list()
print(a)
# with client.Client('2.1', 'admin', 'password','5014449acb984d088b5183cffb1378d1', 'http://172.24.2.10/compute') as nova:
#     a=nova.servers.list()
#     print(a)