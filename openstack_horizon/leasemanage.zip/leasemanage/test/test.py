#-*- coding: utf-8 -*-
from db.lease_db import Appointment,InstanceProblem,InstanceSuccess
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker,scoped_session
engine = create_engine('mysql+pymysql://root:password@172.24.2.10:3306/timemanage',encoding='utf-8', echo=False)
DBSession=sessionmaker(bind=engine,autocommit=False,autoflush=True)
Session=scoped_session(DBSession)
session1=Session()
session2=Session()
session3=DBSession()
session4=DBSession()
print(session1 is session2)
print(session3 is session4)
print(dir(session1))
db_obj=session1.query(Appointment).all()
print(db_obj)