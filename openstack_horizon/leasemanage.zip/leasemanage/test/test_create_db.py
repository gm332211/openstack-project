#-*- coding: utf-8 -*-
import datetime
import views.db_views
def create_list():
    db={
            'instance_name':'test','flavor_id':'c1',
            'image_id':'4aa70b1f-9c49-4d64-9645-0ca21973725e',
            'network_id':'e9223152-48c2-4e3c-8b96-b3e90d073335',
            'start_time':datetime.datetime.now(),
            'stop_time':datetime.datetime.now()
    }
    for i in range(10):
        db['start_time']=datetime.datetime.now()+datetime.timedelta(minutes=i*3)
        db['stop_time'] = datetime.datetime.now() + datetime.timedelta(minutes=i*3+1)
        db['instance_name']='test%s'%(i+1)
        for j in range(10):
            views.db_views.create_app_db(instance_name=db['instance_name'],
                                         image_id=db['image_id'],
                                         flavor_id=db['flavor_id'],
                                         network_id=db['network_id'],
                                         start_time=db['start_time'],
                                         stop_time=db['stop_time'])
views.db_views.delete_all_db()
#Create DB Test
create_list()
#delete all db

