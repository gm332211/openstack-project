# import threading
# def run(test):
#     print(test)
# t1=threading.Thread(target=run,kwargs={'test':'a'})
# t1.kwargs={'test':'b'}
#
#
# class mythread(threading.Thread):
#     def __init__(self,test):
#         threading.Thread.__init__(self)
#         self.test=test
#     def run(self):
#         print(self.test)
#
# t_list=[]
# for i in range(10):
#     t=mythread(test=None)
#     t_list.append(t)
#
#
# db_objs=[x for x in range(99)]
# objs_len=len(db_objs)
# start_len=0
# while start_len<objs_len:
#     count_t = 0
#     if start_len+10 > objs_len:
#         remaining=objs_len-start_len
#         for i in range(start_len,remaining):
#             t_list[count_t].test=i
#             # t_list[count_t].start()
#             count_t += 1
#         for t in t_list:
#             t.join()
#         start_len += remaining
#     else:
#         for i in range(start_len, start_len + 10):
#             t_list[count_t].test = i
#             # t_list[count_t].start()
#             count_t += 1
#         for t in t_list:
#             t.join()
#         start_len+=10


