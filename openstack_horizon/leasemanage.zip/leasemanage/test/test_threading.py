#-*- coding: utf-8 -*-
import threading,time
def run(test):
    while True:
        print(test)
        time.sleep(1)
t1=threading.Thread(target=run,kwargs={'test':'a'})
t1.start()
