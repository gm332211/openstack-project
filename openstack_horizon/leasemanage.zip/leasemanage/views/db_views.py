#-*- coding: utf-8 -*-
from db.lease_db import Appointment,InstanceProblem,InstanceSuccess
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker,scoped_session
import datetime
engine = create_engine('mysql+pymysql://root:password@172.24.2.10:3306/timemanage',encoding='utf-8', echo=False)
DBSession=sessionmaker(bind=engine,autocommit=False,autoflush=False)
Session=scoped_session(DBSession)
def start_timeout():
    session=Session()
    session.commit()
    time_now=datetime.datetime.now()
    db_obj=session.query(Appointment).filter(Appointment.start_time<=time_now).all()
    session.close()
    return db_obj
def stop_timeout():
    session = Session()
    session.commit()
    time_now=datetime.datetime.now()
    db_obj=session.query(InstanceSuccess).filter(InstanceSuccess.stop_time<=time_now).all()
    session.close()
    return db_obj
def create_app_db(instance_name,image_id,flavor_id,network_id,start_time,stop_time):
    session = Session()
    app_obj=Appointment(instance_name=instance_name,image_id=image_id,flavor_id=flavor_id,network_id=network_id,
                             start_time=start_time,stop_time=stop_time)
    session.add(app_obj)
    session.commit()
    session.close()
def create_instance_db(instance_id,start_time,stop_time):
    session=Session()
    instance_obj = InstanceSuccess(instance_id=instance_id,start_time=start_time,stop_time=stop_time)
    session.add(instance_obj)
    session.commit()
    session.close()
def create_problem_db(instance_name,image_id,flavor_id,network_id,start_time,stop_time,status,message):
    session = Session()
    problem_obj=InstanceProblem(instance_name=instance_name,image_id=image_id,flavor_id=flavor_id,network_id=network_id,
                             start_time=start_time,stop_time=stop_time,status=status,message=message)
    session.add(problem_obj)
    session.commit()
    session.close()
def find_all_app_db():
    session = Session()
    session.commit()
    db_objs=session.query(Appointment).all()
    session.close()
    return db_objs
def find_app_db(id):
    session=Session()
    session.commit()
    db_obj=session.query(Appointment).filter(Appointment.id==id).first()
    session.close()
    return db_obj
def find_instance_db(id):
    session=Session()
    session.commit()
    db_obj=session.query(InstanceSuccess).filter(InstanceSuccess.instance_id==id).first()
    session.close()
    return db_obj
def find_all_instance_db():
    session=Session()
    session.commit()
    db_obj=session.query(InstanceSuccess).all()
    session.close()
    return db_obj
def find_all_failure_db():
    session=Session()
    session.commit()
    db_obj=session.query(InstanceProblem).all()
    session.close()
    return db_obj
def find_failure_db(id):
    session=Session()
    session.commit()
    db_obj=session.query(InstanceProblem).filter(InstanceProblem.id==id).first()
    session.close()
    return db_obj
def delete_app_db(id):
    session = Session()
    db_obj = session.query(Appointment).filter(Appointment.id==id).first()
    session.delete(db_obj)
    session.commit()
    session.close()
def delete_db(db_obj):
    session = Session()
    session.delete(db_obj)
    session.commit()
    session.close()

def delete_all_db():
    session = Session()
    a_obj=session.query(Appointment).all()
    p_obj =session.query(InstanceProblem).all()
    s_obj = session.query(InstanceSuccess).all()
    [session.delete(u) for u in a_obj+p_obj+s_obj]
    session.commit()
    session.close()
