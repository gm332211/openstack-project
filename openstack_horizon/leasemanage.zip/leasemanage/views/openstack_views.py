#-*- coding: utf-8 -*-
import httplib,json
from views import db_views
def http_request(ip ,port,url ,method,headers,data=None):
    res=None
    if data:
        data =json.dumps(data)
    else:
        data=json.dumps({})
    conn =httplib.HTTPConnection(ip,port=port)
    if method=='GET':
        conn.request(method=method, url=url, headers=headers)
    elif method=='POST':
        conn.request(method=method ,url=url ,headers=headers ,body=data)
    elif method=='DELETE':
        conn.request(method=method, url=url, headers=headers, body=data)
    try:
        res = conn.getresponse()
    except:
        pass
    if res:
        return res
class openstack(object):
    def __init__(self,ip,username,password,project,domain="Default"):
        self.ip=ip
        self.username=username
        self.password=password
        self.project = project
        self.domain=domain
        self.token=None
    def identity_request(self,server,method,headers=None,data=None):
        port='80'
        ip = self.ip
        service = 'identity'
        version = 'v3'
        url = 'http://%s:%s/%s/%s/%s' % (ip, port, service, version, server)
        if not headers:
            headers={
                "Content-type": "application/json",
            }
        print(ip)
        return http_request(ip=ip, port=port,url=url, method=method, headers=headers, data=data)
    def compute_request(self,server,method,headers=None,data=None):
        port='80'
        ip = self.ip
        service = 'compute'
        version = 'v2.1'
        url = 'http://%s:%s/%s/%s/%s' % (ip, port, service, version, server)
        print('%s %s' % (method, url))
        if not self.token:
            self.get_token()
        if not headers:
            headers={
                "Content-type": "application/json",
                "X-Auth-Token": self.token,
            }
        return http_request(ip=ip,port=port, url=url, method=method, headers=headers, data=data)
    def get_token(self):
        data = {"auth": {"identity": {"methods": ["password"],
                                      "password": {"user": {"name": self.username,"password": self.password,"domain":{"name":self.domain}}}},
                         "scope": {"project": {"name": self.project,"domain":{"name":self.domain}}}}}
        res=self.identity_request(server='auth/tokens',method='POST',data=data)
        self.token=res.getheader('X-Subject-Token')
    def token_verif(self,res):
        if res.status==401:
            self.token=self.get_token()
            return False
        return res
    def server_create(self,db_dict):
        data={
            "server": {
                "name": db_dict.get('instance_name',None),
                "imageRef": db_dict.get('image_id',None),
                "flavorRef": db_dict.get('flavor_id',None),
                "networks":[{'uuid': db_dict.get('network_id',None)}]
            }
        }
        res = self.compute_request('servers', method='POST', data=data)
        res=self.token_verif(res)
        if not res:
            res = self.compute_request('servers', method='POST', data=data)
        self.write_db(res,db_dict)
    def server_delete(self,db_dict=None,id=None):
        if db_dict:
            res=self.compute_request('servers/%s'%db_dict.get('instance_id',None),method='DELETE')
            if res:
                res = self.token_verif(res)
                if not res:
                    self.compute_request('servers/%s' % db_dict.get('instance_id',None), method='DELETE')
            print('delete successs :%s'%db_dict.get('instance_id',None))
        if id:
            res = self.compute_request('servers/%s' % id, method='DELETE')
            if res:
                res = self.token_verif(res)
                print('server_delete', res)
                if not res:
                    self.compute_request('servers/%s' % id, method='DELETE')
            print('delete successs :%s' % id)
    def write_db(self,res,db_dict=None,db=None):
        # data=json.loads(res.read())
        try:
            data=json.loads(res.read())
        except Exception as e:
            print(e)
            print('operation failure ')
            return False
        if res.status>=400:
            for key in data:
                message = data[key].get('message', None)
                print('%s:%s' % (key, message))
                db_views.create_problem_db(
                    instance_name=db_dict.get('instance_name',None), image_id=db_dict.get('image_id',None),
                    flavor_id=db_dict.get('flavor_id',None),network_id=db_dict.get('network_id',None),
                    start_time=db_dict.get('start_time',None), stop_time=db_dict.get('stop_time',None),
                    status=res.status, message=message
                )
        if res.status==202:
            message=None
            for key in data:
                message = data[key].get('message', None)
                print('%s:%s' % (key, message))
            if message:
                db_views.create_problem_db(
                    instance_name=db_dict.get('instance_name',None), image_id=db_dict.get('image_id',None),
                    flavor_id=db_dict.get('flavor_id',None),network_id=db_dict.get('network_id',None),
                    start_time=db_dict.get('start_time',None), stop_time=db_dict.get('stop_time',None),
                    status=res.status, message=message
                )
            if not message:
                instance_id = data['server']['id']
                print('Success Create:%s' % db_dict.get('instance_name',None))
                db_views.create_instance_db(
                    instance_id=instance_id, start_time=db_dict.get('start_time',None), stop_time=db_dict.get('stop_time',None)
                )
    def start_timetout_handle(self):
        db_objs=db_views.start_timeout()
        if db_objs:
            for db_obj in db_objs:
                self.server_create(db_obj)
    def stop_timetout_handle(self):
        db_objs=db_views.stop_timeout()
        if db_objs:
            for db_obj in db_objs:
                self.server_delete(db_obj)
