#-*- coding: utf-8 -*-
import threading,Queue,time
from views import db_views
from openstack_views import openstack
op=openstack(ip='172.24.2.10',username='admin',password='password',project='demo')
start_q=Queue.Queue()
stop_q=Queue.Queue()
def Producer_Create():
    while True:
        db_objs=db_views.start_timeout()
        for db_obj in db_objs:
            db_dict={
                'instance_name':db_obj.instance_name,
                'image_id':db_obj.image_id,
                'flavor_id':db_obj.flavor_id,
                'network_id':db_obj.network_id,
                'start_time':db_obj.start_time,
                'stop_time':db_obj.stop_time,
            }
            start_q.put(db_dict)
            db_views.delete_db(db_obj)
        time.sleep(5)
def Consumer_Create():
    while True:
        db_dict=start_q.get()
        if db_dict:
            op.server_create(db_dict)
def Threading_Create(count=10):
    t_list=[]
    for i in range(count):
        t=threading.Thread(target=Consumer_Create)
        t_list.append(t)
    for t in t_list:
        t.start()
    for t in t_list:
        t.join()
def Producer_Delete():
    while True:
        db_objs=db_views.stop_timeout()
        for db_obj in db_objs:
            db_dict={
                'instance_id':db_obj.instance_id,
                'start_time':db_obj.start_time,
                'stop_time':db_obj.stop_time,
            }
            stop_q.put(db_dict)
            db_views.delete_db(db_obj)
def Consumer_Delete():
    while True:
        db_dict=stop_q.get()
        if db_dict:
            op.server_delete(db_dict)
def Threading_delete(count=10):
    t_list=[]
    for i in range(count):
        t=threading.Thread(target=Consumer_Delete)
        t_list.append(t)
    for t in t_list:
        t.start()
    for t in t_list:
        t.join()
def Threading_Consumer(count=10):
    c_list=[]
    d_list=[]
    for i in range(count):
        c = threading.Thread(target=Consumer_Create)
        d=threading.Thread(target=Consumer_Delete)
        c_list.append(c)
        d_list.append(d)
    for c in c_list:
        c.start()
    for d in d_list:
        d.start()
    for c in c_list:
        c.join()
    for d in d_list:
        d.join()
