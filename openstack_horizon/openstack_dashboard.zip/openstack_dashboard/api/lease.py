from openstack_dashboard.contrib.developer.profiler import api as profiler
from horizon.utils import functions as utils
from django.conf import settings
from openstack_dashboard.api import base
from horizon import exceptions as horizon_exceptions
from openstack_dashboard import api
import json,httplib
flavors_dic={}
images_dic={}
networks_dic={}
def get_images(request):
    images,more,prev = api.glance.image_list_detailed(
        request,
        paginate=True,
        sort_dir='asc',
        sort_key='name',)
    for image in images:
        if not image.id in images_dic:
            images_dic[image.id] = image.name
def get_flavors(request):
    flavors=api.nova.flavor_list(request)
    for flavor in flavors:
        if not flavor.id in flavors_dic:
            flavors_dic[flavor.id]=flavor.name
def get_networks(request):
    networks=api.neutron.network_list(request)
    for network in networks:
        if not network.id in networks_dic:
            networks_dic[network.id] = network.name
def http_request(ip,port,method,url,headers,data):
    res=None
    conn=httplib.HTTPConnection(ip,port)
    conn.request(method=method,url=url,headers=headers,body=data)
    try:
        res=conn.getresponse()
    except:
        pass
    return res
def lease_request(server,method,data=None):
    ip='172.24.2.10'
    port=8567
    url='http://%s:%s/%s'%(ip,port,server)
    headers={
        "Content-type": "application/json",
    }
    res=http_request(ip,port,method,url,headers,data)
    return res
def lease_list_base():
    data=None
    res=lease_request('lease/servers','GET')
    if res:
        data=json.loads(res.read())
    l_list = []
    if data:
        for key in data:
            l_list.append(nova_lease([data[key]]))
    return l_list
def lease_list(request, search_opts=None, detailed=True):
    get_flavors(request)
    get_images(request)
    get_networks(request)
    page_size = utils.get_page_size(request)
    paginate = False
    if search_opts is None:
        search_opts = {}
    elif 'paginate' in search_opts:
        paginate = search_opts.pop('paginate')
        if paginate:
            search_opts['limit'] = page_size + 1

    all_tenants = search_opts.get('all_tenants', False)
    if all_tenants:
        search_opts['all_tenants'] = True
    else:
        search_opts['project_id'] = request.user.tenant_id
    leases = [Server(s, request)
               for s in lease_list_base()]
    # print(leases)
    has_more_data = False
    if paginate and len(leases) > page_size:
        leases.pop(-1)
        has_more_data = True
    elif paginate and len(leases) == getattr(settings, 'API_RESULT_LIMIT',
                                              1000):
        has_more_data = True
    return (leases, has_more_data)
def lease_delete(id):
    lease_request('lease/servers/%s'%id,'DELETE')
def lease_create(instance_name,image_id,flavor_id,network_id,start_time,stop_time):
    data={
        'instance_name':instance_name,
        'image_id': image_id,
        'flavor_id': flavor_id,
        'network_id': network_id,
        'start_time': start_time,
        'stop_time': stop_time,
    }
    print(data)
    lease_request('lease/servers','POST',data=json.dumps(data))
class nova_lease(object):
    def __init__(self,data):
        self.data=data[0]
    @property
    def id(self):
        return self.data.get('uuid',None)
    @property
    def instance_name(self):
        return self.data.get('instance_name', None)
    @property
    def image_id(self):
        return self.data.get('image_id', None)
    @property
    def flavor_id(self):
        return self.data.get('flavor_id', None)
    @property
    def network_id(self):
        return self.data.get('network_id', None)
    @property
    def start_time(self):
        return self.data.get('start_time', None)
    @property
    def stop_time(self):
        return self.data.get('stop_time', None)
    def __str__(self):
        return self.data.get('instance_name', None)
class Server(base.APIResourceWrapper):
    """Simple wrapper around novaclient.server.Server.

    Preserves the request info so image name can later be retrieved.
    """
    _attrs = ['instance_name', 'image_id', 'flavor_id', 'network_id', 'start_time', 'stop_time', 'id']

    def __init__(self, apiresource, request):
        super(Server, self).__init__(apiresource)
        self.request = request
    # TODO(gabriel): deprecate making a call to Glance as a fallback.
    @property
    def image_name(self):
        return images_dic.get(self.image_id, None)
    @property
    def status(self):
        return 'Waiting for creating'
    @property
    def flavor_name(self):
        return flavors_dic.get(self.flavor_id,None)
    @property
    def network_name(self):
        return networks_dic.get(self.network_id,None)
    @property
    def availability_zone(self):
        return getattr(self, 'OS-EXT-AZ:availability_zone', "")


def get_lease_instance():
    success_data={}
    data=None
    res=lease_request('lease/instances','GET')
    if res:
        data=json.loads(res.read())
    if data:
        for key in data:
            success_data[data[key]['instance_id']]={
                'start_time':data[key].get('start_time',None),
                'stop_time': data[key].get('stop_time', None)
            }
    print(success_data)
    return success_data
def instance_list(request, search_opts=None, detailed=True):
    success_data=get_lease_instance()
    i_list=[]
    servers,has_more_data=api.nova.server_list(request,search_opts,detailed)
    for server in servers:
        data=None
        if server.id in success_data:
            data=success_data.get(server.id,None)
        if data:
            setattr(server,'start_time',data.get('start_time',None))
            setattr(server, 'stop_time', data.get('stop_time', None))
            i_list.append(server)
    return (i_list, has_more_data)
def instance_delete(id):
    lease_request('lease/instances/%s'%id,'DELETE')
def instance_get(id):
    res = lease_request('lease/instances/%s'%id, 'GET')
    data={}
    if res:
        data = json.loads(res.read())
    return data

def failure_list_base():
    data=None
    res=lease_request('lease/failures','GET')
    if res:
        data=json.loads(res.read())
    f_list=[]
    if data:
        for key in data:
            f_list.append(nova_failure([data[key]]))
    return f_list
def failure_list(request, search_opts=None, detailed=True):
    get_flavors(request)
    get_images(request)
    get_networks(request)
    page_size = utils.get_page_size(request)
    paginate = False
    if search_opts is None:
        search_opts = {}
    elif 'paginate' in search_opts:
        paginate = search_opts.pop('paginate')
        if paginate:
            search_opts['limit'] = page_size + 1

    all_tenants = search_opts.get('all_tenants', False)
    if all_tenants:
        search_opts['all_tenants'] = True
    else:
        search_opts['project_id'] = request.user.tenant_id
    leases = [FailureInstasnce(s, request)
               for s in failure_list_base()]
    has_more_data = False
    if paginate and len(leases) > page_size:
        leases.pop(-1)
        has_more_data = True
    elif paginate and len(leases) == getattr(settings, 'API_RESULT_LIMIT',
                                              1000):
        has_more_data = True
    return (leases, has_more_data)
def failure_delete(id):
    lease_request('lease/failures/%s'%id,'DELETE')
def failure_reset(id):
    lease_request('lease/failures/%s'%id, 'PUT')
class nova_failure(object):
    def __init__(self,data):
        self.data=data[0]
    @property
    def id(self):
        return self.data.get('uuid',None)
    @property
    def instance_name(self):
        return self.data.get('instance_name', None)
    @property
    def image_id(self):
        return self.data.get('image_id', None)
    @property
    def flavor_id(self):
        return self.data.get('flavor_id', None)
    @property
    def network_id(self):
        return self.data.get('network_id', None)
    @property
    def start_time(self):
        return self.data.get('start_time', None)
    @property
    def stop_time(self):
        return self.data.get('stop_time', None)
    @property
    def status(self):
        return self.data.get('status', None)
    @property
    def message(self):
        return self.data.get('message', None)
    def __str__(self):
        return self.data.get('instance_name', None)
class FailureInstasnce(base.APIResourceWrapper):
    """Simple wrapper around novaclient.server.Server.

    Preserves the request info so image name can later be retrieved.
    """
    _attrs = ['instance_name', 'image_id', 'flavor_id', 'network_id', 'start_time', 'stop_time', 'id','status','message']

    def __init__(self, apiresource, request):
        super(FailureInstasnce, self).__init__(apiresource)
        self.request = request
    # TODO(gabriel): deprecate making a call to Glance as a fallback.
    @property
    def image_name(self):
        return images_dic.get(self.image_id,None)
    @property
    def flavor_name(self):
        return flavors_dic.get(self.flavor_id,None)
    def network_name(self):
        return networks_dic.get(self.network_id,None)
    @property
    def internal_name(self):
        return getattr(self, 'OS-EXT-SRV-ATTR:instance_name', "")
    @property
    def availability_zone(self):
        return getattr(self, 'OS-EXT-AZ:availability_zone', "")
    @property
    def host_server(self):
        return getattr(self, 'OS-EXT-SRV-ATTR:host', '')

class Hypervisor(base.APIDictWrapper):
    """Simple wrapper around novaclient.hypervisors.Hypervisor."""

    _attrs = ['manager', '_loaded', '_info', 'hypervisor_hostname', 'id',
              'servers']

    @property
    def servers(self):
        # if hypervisor doesn't have servers, the attribute is not present
        servers = []
        try:
            servers = self._apidict.servers
        except Exception:
            pass

        return servers






