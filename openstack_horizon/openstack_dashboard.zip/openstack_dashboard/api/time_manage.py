# from sqlalchemy import Column,String,Date,create_engine
# from sqlalchemy.orm import sessionmaker
# from sqlalchemy.ext.declarative import declarative_base
# Base=declarative_base()
# class Appointment(Base):
#     __tablename__='appointment'
#     id=Column(String(64),primary_key=True)
#     instance_name=Column(String(64))
#     image_id=Column(String(64))
#     flavor_id=Column(String(64))
#     network_id=Column(String(64))
#     start_time=Column(Date())
#     stop_time=Column(Date())
# engine=create_engine('mysql+mysqlconnector://root:password@localhost:3306/test')
# DBSession = sessionmaker(bind=engine)
# session=DBSession()
from openstack_dashboard.api import base

class Server(base.APIResourceWrapper):
    """Simple wrapper around novaclient.server.Server.

    Preserves the request info so image name can later be retrieved.
    """
    _attrs = ['addresses', 'attrs', 'id', 'image', 'links', 'description',
              'metadata', 'name', 'private_ip', 'public_ip', 'status', 'uuid',
              'image_name', 'VirtualInterfaces', 'flavor', 'key_name', 'fault',
              'tenant_id', 'user_id', 'created', 'locked',
              'OS-EXT-STS:power_state', 'OS-EXT-STS:task_state',
              'OS-EXT-SRV-ATTR:instance_name', 'OS-EXT-SRV-ATTR:host',
              'OS-EXT-AZ:availability_zone', 'OS-DCF:diskConfig']

    def __init__(self, apiresource, request):
        super(Server, self).__init__(apiresource)
        self.request = request

    # TODO(gabriel): deprecate making a call to Glance as a fallback.
    @property
    def image_name(self):
        import glanceclient.exc as glance_exceptions
        from openstack_dashboard.api import glance

        if not self.image:
            return None
        elif hasattr(self.image, 'name'):
            return self.image.name
        elif 'name' in self.image:
            return self.image['name']
        else:
            try:
                image = glance.image_get(self.request, self.image['id'])
                self.image['name'] = image.name
                return image.name
            except (glance_exceptions.ClientException,
                    horizon_exceptions.ServiceCatalogException):
                self.image['name'] = None
                return None

    @property
    def internal_name(self):
        return getattr(self, 'OS-EXT-SRV-ATTR:instance_name', "")

    @property
    def availability_zone(self):
        return getattr(self, 'OS-EXT-AZ:availability_zone', "")

    @property
    def host_server(self):
        return getattr(self, 'OS-EXT-SRV-ATTR:host', '')
