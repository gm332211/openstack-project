from horizon import tables
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ungettext_lazy
from django.utils.translation import string_concat
import logging
from django.http import HttpResponse
from django import urls
from django.conf import settings
from openstack_dashboard import api
LOG = logging.getLogger(__name__)
class MyfilterAcation(tables.FilterAction):
    name='myfilter'
class DeleteFailure(tables.DeleteAction):
    help_text = _("Deleted Failure are not recoverable.")
    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Delete Failure",
            u"Delete Failure",
            count
        )

    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Scheduled deletion of Failure",
            u"Scheduled deletion of Failure",
            count
        )

    def allowed(self, request, instance=None):
        return True

    def action(self, request, obj_id):
        print(obj_id)
        print('delete success')
        # api.nova.server_delete(request, obj_id)
        api.lease.failure_delete(obj_id)
class ResetFailure(tables.BatchAction):
    name = "reset"
    classes = ('btn-confirm',)
    # policy_rules = (("compute", "os_compute_api:servers:start"),)

    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Reset",
            u"Reset",
            count
        )

    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Reset",
            u"Reset",
            count
        )

    def allowed(self, request, instance=None):
        return True

    def action(self, request, obj_id):
        print('reset success')
        api.lease.failure_reset(obj_id)

class FailureTable(tables.DataTable):
    instance_name=tables.Column('instance_name',verbose_name=_('Instance Name'))
    image_name=tables.Column('image_name',verbose_name=_('Image'))
    flavor_name=tables.Column('flavor_name',verbose_name=_('Flavor'))
    network_id=tables.Column('network_name',verbose_name=_('Network'))
    status=tables.Column('status',verbose_name=_('Status'))
    message=tables.Column('message',verbose_name=_('Message'))
    start_time = tables.Column('start_time', verbose_name=_('Start Time'),)
    stop_time = tables.Column('stop_time', verbose_name=_('End Time'),)
    class Meta(object):
        name='lease_failure'
        verbose_name=_('Lease Failure')
        table_actions = (MyfilterAcation,ResetFailure,DeleteFailure)