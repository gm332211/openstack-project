from horizon import tabs
from openstack_dashboard.dashboards.mydashboard.failure import tables
from openstack_dashboard import api
from horizon import exceptions
from django.utils.translation import ugettext_lazy as _
class Failuretab(tabs.TableTab):
    name=_('Failure Tab')
    slug='Failure_tab'
    table_classes = (tables.FailureTable,)
    page_title = _("Lease Failure")
    template_name=('horizon/common/_detail_table.html')
    preload=False
    def has_more_data(self, table):
        print('has more',self._has_more)
        return self._has_more
    def get_lease_failure_data(self):
        try:
            marker=self.request.GET.get(tables.FailureTable._meta.pagination_param,None)
            lease,self._has_more=api.lease.failure_list(self.request,search_opts={'marker':marker,'paginate':True})
            return lease
        except Exception:
            self._has_more=False
            error_message=_('Unable to get Lease')
            exceptions.handle(self.request,error_message)
            return []

class Mypaneltabs(tabs.TabGroup):
    slug = 'failure_tabs'
    tabs=(Failuretab,)
    sticky = True