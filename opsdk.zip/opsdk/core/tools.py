# -*- coding: utf-8 -*-
# author:xiaoming
def help_list(data=None):
    '''帮助 :已完成'''
    from conf.setting import help_dic
    if data:
        help_dic.get(data)
        for key in help_dic[data]:
            print(data,key)
    else:
        for key in help_dic:
            for i in help_dic[key]:
                print(key,i,help_dic[key][i])
    exit()
def out_beautiful(data):
    print('----%s----'%(data))
